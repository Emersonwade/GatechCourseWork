namespace cpp proxy

service RpcProxy {

	string getWebpage(1:string url)
	
}