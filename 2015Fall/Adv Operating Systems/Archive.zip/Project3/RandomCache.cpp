#include "RandomCache.h"

RandomCache::RandomCache(size_t size) {
    cacheSize = size;
}

RandomCache::~RandomCache() {
    
}