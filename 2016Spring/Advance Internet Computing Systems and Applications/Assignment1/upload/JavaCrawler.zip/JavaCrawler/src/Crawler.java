import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Crawler extends Thread {
	public static DB db = new DB();
	private String URL;
	private ArrayList<String> urlArray;
	private String keyword;
	private String links;
	private int crawlerNum;
	
	public Crawler(String URL, String keyword, String links, int crawlerNum){ 
		this.URL = URL;
		this.urlArray = new ArrayList<String>();
		this.keyword = keyword;
		this.links = links;
		this.crawlerNum = crawlerNum;
	}

	
    public void run() {
    	try {
			processPage(URL, urlArray, keyword, links, crawlerNum);
			saveArrayToDB(urlArray);
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
	public static void processPage(String URL, ArrayList<String> urlArray, 
			String keyword, String links, int crawlerNum) throws SQLException, IOException {
		if (urlArray.size() >= crawlerNum || urlArray.contains(URL)) {
			return;
		}

		urlArray.add(URL);
		System.out.println(URL);
		try {
			Document doc = Jsoup.connect(URL).timeout(10 * 1000).get();
			if (doc.text().contains(keyword)) {
				Elements questions = doc.select("a[href]");
				for (Element link : questions) {
					if (link.attr("href").contains(links))
						processPage(link.attr("abs:href"), urlArray, keyword, links, crawlerNum);
				}
			}
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			urlArray.remove(URL);
			// e.printStackTrace();
		} catch (HttpStatusException e) {
			urlArray.remove(URL);
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			urlArray.remove(URL);
			// e.printStackTrace();
		}

	}
	
	public static void saveArrayToDB(ArrayList<String> urlArray) throws SQLException, IOException {
		for (String url : urlArray) {
			String sql = "INSERT INTO  `JavaCrawler`.`Record` " + "(`URL`) VALUES " + "(?);";
			PreparedStatement stmt = db.conn.prepareStatement(sql,
			Statement.RETURN_GENERATED_KEYS); 
			stmt.setString(1, url); 
			stmt.execute();
		}
	}
}
