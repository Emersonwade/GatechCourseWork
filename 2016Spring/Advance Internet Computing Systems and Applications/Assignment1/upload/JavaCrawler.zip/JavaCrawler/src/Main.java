import java.io.Console;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws SQLException, IOException {
		int THREAD_NUM = Integer.parseInt(args[0]);
		int crawlerNum = Integer.parseInt(args[1]);
		ArrayList<Thread> threadList = new ArrayList<Thread>();
	    
		for (int i = 0; i < THREAD_NUM; i++) {
			Console console = System.console();
		    String seedURL = console.readLine("Please enter SeedURL : ");  
		    String keyword = console.readLine("Please enter keyword : ");   
		    String links = console.readLine("Please enter links : ");   

			Thread crawler = new Crawler(seedURL, keyword, links, crawlerNum);
			threadList.add(crawler);
		}
		
		for (Thread thread : threadList) {
			thread.start();
		}
	}
}